﻿# WhatsApp Automation Project
هذا المشروع يحتوي على سكريبت لأتمتة رسائل واتساب
